//
//  TapSDKConstants.h
//  TapBootstrapSDK
//
//  Created by Bottle K on 2021/2/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN int const ERROR_CODE_UNDEFINED;
FOUNDATION_EXTERN int const ERROR_CODE_UNINITIALIZED;

NS_ASSUME_NONNULL_END
