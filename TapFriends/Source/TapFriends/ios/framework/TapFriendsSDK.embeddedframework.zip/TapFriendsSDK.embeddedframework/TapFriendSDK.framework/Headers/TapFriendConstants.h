//
//  TapFriendConstants.h
//  TapFriendSDK
//
//  Created by Bottle K on 2021/5/11.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXTERN int const TAP_FRIEND_EVENT_INVITATION;
