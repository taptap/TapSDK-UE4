//
//  TapFriends.h
//  TapFriends
//
//  Created by Bottle K on 2021/3/16.
//

#define TapFriendSDK                @"TapFriend"
#define TapFriendSDK_VERSION_NUMBER @"30601001"
#define TapFriendSDK_VERSION        @"3.6.1"
