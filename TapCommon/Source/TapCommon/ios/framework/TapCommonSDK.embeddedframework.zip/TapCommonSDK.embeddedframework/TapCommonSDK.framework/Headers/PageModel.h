//
//  PageModel.h
//  TDSCommon
//
//  Created by TapTap-David on 2021/1/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PageModel : NSObject
@property (nonatomic, copy) NSString *page;
@end

NS_ASSUME_NONNULL_END
