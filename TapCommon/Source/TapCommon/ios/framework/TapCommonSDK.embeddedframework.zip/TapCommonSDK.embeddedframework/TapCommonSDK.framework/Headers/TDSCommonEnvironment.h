//
//  TDSCommonEnvironment.h
//  TDSCommon
//
//  Created by Bottle K on 2021/1/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TDSCommonEnvironment : NSObject

+ (bool)isCurrentRND;
@end

NS_ASSUME_NONNULL_END
