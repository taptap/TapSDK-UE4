//
//  TDSSDK.h
//  TDSCommon
//
//  Created by Bottle K on 2020/10/13.
//

#import <Foundation/Foundation.h>
#import <TapCommonSDK/TDSAccount.h>

#define TapCommonSDK @"TapCommon"
#define TapCommonSDK_VERSION_NUMBER @"30500001"
#define TapCommonSDK_VERSION        @"3.5.0"

NS_ASSUME_NONNULL_BEGIN

@interface TDSBaseManager : NSObject

@end

NS_ASSUME_NONNULL_END
