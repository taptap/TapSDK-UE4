//
//  TapFriendUI.h
//  TapFriendUISDK
//
//  Created by Bottle K on 2021/5/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define TapFriendUISDK @"TapFriendUI"
#define TapFriendUISDK_VERSION_NUMBER @"20103001"
#define TapFriendUISDK_VERSION        @"2.1.3"

@interface TapFriendUI : NSObject

@end

NS_ASSUME_NONNULL_END
