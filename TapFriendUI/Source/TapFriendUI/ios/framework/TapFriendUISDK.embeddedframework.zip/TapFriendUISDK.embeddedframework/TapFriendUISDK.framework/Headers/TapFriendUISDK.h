//
//  TapFriendUISDK.h
//  TapFriendUISDK
//
//  Created by Bottle K on 2021/5/11.
//

#import <Foundation/Foundation.h>

//! Project version number for TapFriendUISDK.
FOUNDATION_EXPORT double TapFriendUISDKVersionNumber;

//! Project version string for TapFriendUISDK.
FOUNDATION_EXPORT const unsigned char TapFriendUISDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TapFriendUISDK/PublicHeader.h>


